const express = require("express");
const fs = require("fs");
const { exec } = require("child_process");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static("public"));

app.post("/tts", async (req, res) => {
  const texto = req.body?.texto;
  if (!texto) return res.status(400).send({ error: "Texto não fornecido." });

  const nome = `voz_${Date.now()}.mp3`;
  const caminho = path.join(__dirname, "public", nome);
  const comando = `gtts-cli "${texto}" --lang pt -o "${caminho}"`;

  exec(comando, (err) => {
    if (err) {
      console.error("Erro ao gerar áudio:", err.message);
      return res.status(500).send({ error: "Erro ao gerar áudio" });
    }
    res.send({ url: `/${nome}` });
  });
});

app.get("/", (req, res) => {
  res.send("Servidor TTS online");
});

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log("Servidor rodando na porta", PORT));